import { SwiperSlide } from 'swiper/react';
import type { Product } from '../../types/products';
import { ProductCard } from '../ProductCard';
import './ProductList.scss';

type Props = {
  visibleProducts: Product[];
};

export const ProductList: React.FC<Props> = ({ visibleProducts }) => {
  return (
    <>
      {visibleProducts.map((product) => (
        <SwiperSlide key={product.id}>
          <ProductCard
            product={product}
            category={product.category}
          />
        </SwiperSlide>
      ))}
    </>
  );
};
