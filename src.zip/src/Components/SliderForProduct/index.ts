export * from './SliderForProduct';
