export * from './TechSpecs';
