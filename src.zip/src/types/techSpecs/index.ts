export * from './techSpecs';
