export type DictionarySection = Record<string, string>;
