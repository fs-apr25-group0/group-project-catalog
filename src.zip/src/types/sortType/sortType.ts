import type { sortVariants } from "../../constans/sortVariants";

export type SortType = keyof typeof sortVariants