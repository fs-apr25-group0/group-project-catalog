export type Language = 'en' | 'ua';
