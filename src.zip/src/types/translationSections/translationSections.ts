export type TranslationSection = 'titleSection' | 'titleText' | 'common';
