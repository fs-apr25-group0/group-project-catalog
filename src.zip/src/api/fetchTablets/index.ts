export * from './fetchTablets';
