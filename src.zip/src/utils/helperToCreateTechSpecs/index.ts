export * from './helperToCreateTechSpecs';
